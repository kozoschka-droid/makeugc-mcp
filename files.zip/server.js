import express from "express";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { z } from "zod";

const MAKEUGC_API_KEY = process.env.MAKEUGC_API_KEY;
const BASE_URL = "https://app.makeugc.ai/api/platform";

if (!MAKEUGC_API_KEY) {
  console.error("ERROR: MAKEUGC_API_KEY environment variable is not set.");
  process.exit(1);
}

async function makeugcRequest(path, { method = "GET", query, body } = {}) {
  let url = `${BASE_URL}${path}`;
  if (query) {
    const params = new URLSearchParams(
      Object.entries(query).filter(([, v]) => v !== undefined && v !== null && v !== "")
    );
    const qs = params.toString();
    if (qs) url += `?${qs}`;
  }

  const res = await fetch(url, {
    method,
    headers: {
      "X-Api-Key": MAKEUGC_API_KEY,
      ...(body ? { "Content-Type": "application/json" } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  const text = await res.text();
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    data = { raw: text };
  }

  if (!res.ok) {
    throw new Error(
      `MakeUGC API error (${res.status}): ${data?.message || text || "Unknown error"}`
    );
  }
  return data;
}

function toolResult(data) {
  return {
    content: [{ type: "text", text: JSON.stringify(data, null, 2) }],
  };
}

function errorResult(err) {
  return {
    content: [{ type: "text", text: `Error: ${err.message}` }],
    isError: true,
  };
}

function buildServer() {
  const server = new McpServer({
    name: "makeugc-mcp",
    version: "1.0.0",
  });

  // --- Avatars & Voices ---

  server.tool(
    "list_avatars",
    "List available MakeUGC avatars (template and custom). Optionally filter by gender.",
    { gender: z.enum(["Male", "Female"]).optional() },
    async ({ gender }) => {
      try {
        const data = await makeugcRequest("/video/avatars", { query: { gender } });
        return toolResult(data);
      } catch (err) {
        return errorResult(err);
      }
    }
  );

  server.tool(
    "list_voices",
    "List available MakeUGC voices (template and custom). Optionally filter by language and/or gender.",
    {
      language: z.string().optional(),
      gender: z.enum(["Male", "Female"]).optional(),
    },
    async ({ language, gender }) => {
      try {
        const data = await makeugcRequest("/video/voices", { query: { language, gender } });
        return toolResult(data);
      } catch (err) {
        return errorResult(err);
      }
    }
  );

  // --- Standard video generation ---

  server.tool(
    "generate_video",
    "Generate an AI avatar video from a script. Returns a video id — use check_video_status to poll for completion.",
    {
      avatar_id: z.string().describe("ID of the avatar, from list_avatars"),
      voice_script: z.string().max(1500).describe("Script for the voice, max 1500 characters"),
      video_name: z.string().optional(),
      voice_url: z.string().url().optional().describe("URL to existing audio, max 120s, skips TTS"),
      voice_id: z.string().optional().describe("Voice actor ID, from list_voices"),
      voice_settings: z
        .object({
          stability: z.number().min(0).max(1).optional(),
          similarity_boost: z.number().min(0).max(1).optional(),
          style: z.number().min(0).max(1).optional(),
          use_speaker_boost: z.boolean().optional(),
        })
        .optional(),
      webhook_url: z.string().url().optional(),
    },
    async (params) => {
      try {
        const data = await makeugcRequest("/video/generate", { method: "POST", body: params });
        return toolResult(data);
      } catch (err) {
        return errorResult(err);
      }
    }
  );

  server.tool(
    "check_video_status",
    "Check the status of a standard video generation job by id.",
    { id: z.string() },
    async ({ id }) => {
      try {
        const data = await makeugcRequest("/video/status", { query: { id } });
        return toolResult(data);
      } catch (err) {
        return errorResult(err);
      }
    }
  );

  // --- Custom avatar ---

  server.tool(
    "generate_custom_avatar",
    "Create a custom avatar from a publicly accessible image URL (and optional voice sample URL).",
    {
      image_url: z.string().url().describe("Public URL to a clear portrait photo"),
      voice_url: z.string().url().optional().describe("Public URL to a voice sample; random voice used if omitted"),
    },
    async ({ image_url, voice_url }) => {
      try {
        const form = new FormData();
        form.append("image", image_url);
        if (voice_url) form.append("voice", voice_url);

        const res = await fetch(`${BASE_URL}/custom-avatar/generate`, {
          method: "POST",
          headers: { "X-Api-Key": MAKEUGC_API_KEY },
          body: form,
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data?.message || "Request failed");
        return toolResult(data);
      } catch (err) {
        return errorResult(err);
      }
    }
  );

  // --- Product-in-hand ---

  server.tool(
    "generate_product_in_hand_video",
    "Generate a Product-in-Hand video using the Nova V2 or Omi-Human or Veo model.",
    {
      model: z.enum(["nova-v2", "omi-human", "veo"]),
      image_url: z.string().url(),
      script: z.string().optional(),
      voice_url: z.string().url().optional(),
      voice_id: z.string().optional(),
      project_id: z.string().optional(),
      end_image_url: z.string().url().optional().describe("Veo only: target ending frame URL"),
      veo_model: z.enum(["pro", "fast"]).optional().describe("Veo only: quality tier"),
      scenes: z
        .array(z.object({ script: z.string(), description: z.string() }))
        .min(1)
        .max(4)
        .optional()
        .describe("Veo only: 1-4 scenes, required for veo model"),
      webhook_url: z.string().url().optional(),
    },
    async ({ model, veo_model, ...rest }) => {
      try {
        const body = { ...rest };
        if (model === "veo" && veo_model) body.model = veo_model;
        const data = await makeugcRequest(`/product-in-hand/${model}/generate`, {
          method: "POST",
          body,
        });
        return toolResult(data);
      } catch (err) {
        return errorResult(err);
      }
    }
  );

  server.tool(
    "check_product_in_hand_status",
    "Check the status of a Product-in-Hand video generation job.",
    { id: z.string() },
    async ({ id }) => {
      try {
        const data = await makeugcRequest("/product-in-hand/status", { query: { id } });
        return toolResult(data);
      } catch (err) {
        return errorResult(err);
      }
    }
  );

  // --- Content library templates ---

  server.tool(
    "list_content_library_categories",
    "List available Content Library template categories.",
    {},
    async () => {
      try {
        const data = await makeugcRequest("/content-library/categories");
        return toolResult(data);
      } catch (err) {
        return errorResult(err);
      }
    }
  );

  server.tool(
    "list_content_library_templates",
    "List Content Library templates, optionally filtered by category. Each template lists its required fields.",
    { category: z.string().optional() },
    async ({ category }) => {
      try {
        const data = await makeugcRequest("/content-library/templates", { query: { category } });
        return toolResult(data);
      } catch (err) {
        return errorResult(err);
      }
    }
  );

  server.tool(
    "generate_content_library_video",
    "Generate a video from a Content Library template. Pass template_id plus any fields required by that template (see list_content_library_templates for the required field names, e.g. product_name, product_image, script).",
    {
      template_id: z.string(),
      project_id: z.string().optional(),
      webhook_url: z.string().url().optional(),
      fields: z
        .record(z.string())
        .describe("Key-value map of the template's dynamic required fields, e.g. { product_name: '...', product_image: 'https://...', script: '...' }"),
    },
    async ({ template_id, project_id, webhook_url, fields }) => {
      try {
        const body = { template_id, project_id, webhook_url, ...fields };
        const data = await makeugcRequest("/content-library/generate", { method: "POST", body });
        return toolResult(data);
      } catch (err) {
        return errorResult(err);
      }
    }
  );

  server.tool(
    "check_content_library_status",
    "Check the status of a Content Library video generation job by db_id.",
    { id: z.string() },
    async ({ id }) => {
      try {
        const data = await makeugcRequest("/content-library/status", { query: { id } });
        return toolResult(data);
      } catch (err) {
        return errorResult(err);
      }
    }
  );

  return server;
}

const app = express();
app.use(express.json());

app.post("/mcp", async (req, res) => {
  try {
    const server = buildServer();
    const transport = new StreamableHTTPServerTransport({
      sessionIdGenerator: undefined,
    });
    res.on("close", () => {
      transport.close();
      server.close();
    });
    await server.connect(transport);
    await transport.handleRequest(req, res, req.body);
  } catch (err) {
    console.error("MCP request error:", err);
    if (!res.headersSent) {
      res.status(500).json({
        jsonrpc: "2.0",
        error: { code: -32603, message: "Internal server error" },
        id: null,
      });
    }
  }
});

app.get("/", (req, res) => {
  res.send("MakeUGC MCP server is running. Point your Claude custom connector at /mcp.");
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`MakeUGC MCP server listening on port ${PORT}`);
});
