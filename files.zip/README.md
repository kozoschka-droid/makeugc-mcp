# MakeUGC MCP Server

A remote MCP server that wraps the MakeUGC Platform API, so Claude can generate
avatar videos, product-in-hand videos, and Content Library videos directly.

## Tools exposed

- `list_avatars`, `list_voices`
- `generate_video`, `check_video_status`
- `generate_custom_avatar`
- `generate_product_in_hand_video`, `check_product_in_hand_status`
- `list_content_library_categories`, `list_content_library_templates`
- `generate_content_library_video`, `check_content_library_status`

## 1. Deploy it somewhere public (Render.com free tier example)

Claude connects to your server over the public internet, so it can't run on
your own laptop. Render's free tier is the easiest option for a personal tool.

1. Create a free account at https://render.com
2. Push this folder to a new GitHub repo (or use Render's "public git repo"
   option if you don't want your own repo).
3. In Render: **New > Web Service** → connect the repo.
4. Build command: `npm install`
5. Start command: `npm start`
6. Under **Environment**, add a variable:
   - `MAKEUGC_API_KEY` = your MakeUGC API key (from the screen where you
     generated it — never paste this into a chat with Claude)
7. Deploy. Render will give you a URL like
   `https://makeugc-mcp-xxxx.onrender.com`

Your MCP endpoint is then: `https://makeugc-mcp-xxxx.onrender.com/mcp`

(Any other Node host — Railway, Fly.io, a VPS — works the same way: install
deps, set `MAKEUGC_API_KEY`, run `npm start`, expose it over HTTPS.)

## 2. Add it to Claude as a custom connector

1. In the Claude app: **Settings > Connectors** (on claude.ai:
   Settings > Connectors).
2. Click **Add custom connector**.
3. Paste your `/mcp` URL from step 1.
4. Click **Add**, then enable it for your conversation via the "+" button.

No OAuth is needed here since auth is handled server-side via the
`MAKEUGC_API_KEY` environment variable — Claude never sees the key directly.

## Local testing (optional)

```bash
npm install
MAKEUGC_API_KEY=your_key npm start
```

Server listens on port 3000 by default; the MCP endpoint is `/mcp`.
